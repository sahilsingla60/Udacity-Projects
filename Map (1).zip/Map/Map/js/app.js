var dest = [{
		pName: 'Kingdom Of Dreams',
		selection: false,
		pId: "4b7e34f0f964a52010e62fe3",
		show: true,
		lat: 28.467931,
		long: 77.0658812
	},
	{
		pName: 'Leisure Valley Park',
		selection: false,
		pId: "51efd341498eccca550ecf1f",
		show: true,
		lat: 28.4697441,
		long: 77.0639802
	},
	{
		pName: 'Sheetla Mata Mandir',
		selection: false,
		pId: "50c3641ee4b070f4c21fccad",
		show: true,
		lat: 28.4781324,
		long: 77.0278304
	},
	{
		pName: 'Plaza Mall',
		selection: false,
		pId: "4de0a23fae605835c458b37a",
		show: true,
		lat: 28.477871,
		long: 77.0708899
	},
	{
		pName: 'DLF Cyber Hub',
		selection: false,
		pId: "5257ea5111d20d6aea85a5b6",
		show: true,
		lat: 28.4953905,
		long: 77.0862731
	},
	{
		pName: 'Li & Fung',
		selection: false,
		pId: "4f69a51de4b0de8713327faf",
		show: true,
		lat: 28.512833,
		long: 77.0840494
	}
];


//viewmodel

var viewmodel = function () {

	var self = this;

	self.error = ko.observable('');
	self.place = ko.observableArray([]);
	self.lInput = ko.observable('');

	//creation of marker
	dest.forEach(function (count) {

		var marker = new google.maps.Marker({
			pName: count.pName,
			position: {
				lat: count.lat,
				lng: count.long
			},
			show: ko.observable(count.show),
			animation: google.maps.Animation.DROP,
			pId: count.pId,
			map: map,
			selection: ko.observable(count.select),
			id: 1
		});

		self.place.push(marker);

		//animating marker
		marker.addListener('click', function () {
			self.markerBounce(marker);
			self.apiData(marker);
			self.datawindow(this, infowindow);


		});

	});

	var infowindow = new google.maps.InfoWindow();
	self.datawindow = function (marker, infowindow) {

		if (infowindow.marker != marker) {
			infowindow.setContent('');
			infowindow.marker = marker;
		}

	};
	self.markerBounce = function (anim) {
		anim.setAnimation(google.maps.Animation.BOUNCE);
		setTimeout(function () {
			anim.setAnimation(null);
		}, 1200);
	};

	//Foursquare data
	self.apiData = function (marker) {
		$.ajax({
			url: 'https://api.foursquare.com/v2/venues/' + marker.pId + '?client_id=GTYWO153A5TPHM5A1C3JVTGBZFXLEVSNAKDFIEXR4BOAVRJP&client_secret=CQ0HMDWQI5RVMTK12DYTRUVJM3QR1Y5GXDGFD1DPQFCCLPWI&v=20170527',
			dataType: "json",
			success: function (data) {

				marker.likes = data.response.venue.likes.hasOwnProperty('summary') ? data.response.venue.likes.summary : "Information not available";
				marker.contact = data.response.venue.contact.hasOwnProperty('phone') ? data.response.venue.contact.phone : "Information not available";
				infowindow.setContent('<h3>' + marker.pName + '</h3>' + '<br>' + 'Likes: ' + marker.likes + '</br>Contact: ' + marker.contact);
				infowindow.open(map, marker);
			},
			error: function (e) {
				self.error("Your Foursquare data is not valid ");
			}
		});
	};


	self.touchList = function (marker) {

		google.maps.event.trigger(marker, 'click');
	};

	self.Show = function (binary) {
		for (var mark = 0; mark < self.place().length; mark++) {
			self.place()[mark].show(binary);
			self.place()[mark].setVisible(binary);
		}
	};

	var lower;
	var pos;
	self.find = function () {
		var refresh = self.lInput();

		//shows list according to input
		if (refresh.length === 0) {
			self.Show(true);
		} else {
			for (var mark = 0; mark < self.place().length; mark++) {

				lower = self.place()[mark].pName.toLowerCase();
				pos = lower.indexOf(refresh.toLowerCase());

				if (pos > -1) {
					self.place()[mark].show(true);
					self.place()[mark].setVisible(true);
				} else {
					self.place()[mark].show(false);
					self.place()[mark].setVisible(false);
				}
			}
		}
	};


};


var map;

//checking of error
function MapError() {
	alert("Check your google API");
}

//Map is intialised
function initMap() {
	var initialloc = new google.maps.LatLng(28.467931, 77.0658812);

	var mapOptions = {
		zoom: 12,
		center: initialloc};

	map = new google.maps.Map(document.querySelector("#mapchanger"), mapOptions);
	ko.applyBindings(new viewmodel());

}
