#Neighborhood Map Project

#The project shows Gurgaon now known as Gurugram neighbourhood map.


#Framework used
* KnockoutJS
* BootStrap
* jQuery

#API used
* Google map API
* Foursquare API

* The neighbourhood folder contains CSS folder, js folder and index file.

#Steps to run the project
* Open Neighborhood Map folder.
* Open the index.html and the webpage shows different locations of gurugram.
