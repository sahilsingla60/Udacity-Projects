# favorite_movies_project

media.py file creates a class Movie having 4 variables which are title, storyline, poster_image_url, trailer_youtube_url.

project.py file creates instances of Movie class, insert them in a list and pass the list as an argument to fresh_tomatoes.py file.

fresh_tomatoes.py creates a webpage with the provided data. It also styles the web page.

Open movies.html to enjoy movie website and watching trailers or you can also open page by typing python project.py in terminal. You can click on the movie poster or title to watch trailer.You can hover the mouse over the poster to get description of movie.

If you want to add your favourites this page, don't worry just open the file project.py and add the information of the movie you want to add.After doing so, save the file and run that file. Your output will be produced in the form of movies.html.

Happy Watching!!
