import media
import fresh_tomatoes

# Following are 6 objects of class Movie.
# This code makes an instance of Movie class and initialises it with 4 values
# as arguments which become title, storyline, poster_image_url and
# trailer_youtube_url of object.

# Raabta Movie: Movie title,Poster Image,Movie Trailor
Raabta = media.Movie(
                    "Raabta",
                    "http://t2.gstatic.com/images?q=tbn:ANd9GcRwchuikezYdG9hqmBbwmmr9tdIfH__1xP1huKeeRLmFkQm7cWA",  # NOQA
                    "https://www.youtube.com/watch?v=YXjYfpqg8Z0")
# Fan: Movie title,Poster Image,Movie Trailor
Fan = media.Movie("Fan",
"http://t1.gstatic.com/images?q=tbn:ANd9GcQkEZCmDmmi1UYbAMuu0TzK59JtwdfRyQgxiQoB57NJ8_zDYzAs",  # NOQA
"https://www.youtube.com/watch?v=nkS_Ar0Yad0"
)
# Shudd Desi Romance: Movie title,Poster Image,Movie Trailor
Shudd_Desi_Romance = media.Movie(
                    "Shudd Desi Romance",
                    "http://t2.gstatic.com/images?q=tbn:ANd9GcSlNRvNWN29CjP3nufYK15_Jn0eTlDksB3GDGDbiSViZIjm7Law",  # NOQA
                    "https://www.youtube.com/watch?v=o2Hle83Plpo"
                                )
# Pk: Movie title,Poster Image,Movie Trailor
Pk = media.Movie("Pk",
"http://t1.gstatic.com/images?q=tbn:ANd9GcQSSaD2bSPOgmgsn4-09dF2l8mHbuvHhJxbkL7rvD1uEpAxKnLX",  # NOQA
"https://www.youtube.com/watch?v=SOXWc32k4zA"
)
# Kai Po Chi: Movie title,Poster Image,Movie Trailor
Kai_Po_Chi = media.Movie("Kai Po Chi",
"http://t3.gstatic.com/images?q=tbn:ANd9GcRNkxOtE3YGplodBqxdO0i8lScVa1jvyekPKCk2AW8vad2JCIA_",  # NOQA
"https://www.youtube.com/watch?v=fdXD5YIEhuA")
# M_S: Movie title,Poster Image,Movie Trailor
M_S = media.Movie("M.S.Dhoni:Untold Story",
"http://t0.gstatic.com/images?q=tbn:ANd9GcSbgMguXb4cBUMBEdZkYA_CpjHWHQQpPPNrMnBvp5PDeXiMedL-",  # NOQA
"https://www.youtube.com/watch?v=6L6XqWoS8tw"
)
# list named movies that contains objects created above.
movies = [Raabta, Fan, Shudd_Desi_Romance, Pk, Kai_Po_Chi, M_S]
# list is passed as argument to open_movies_page function of fresh_tomatoes.
fresh_tomatoes.open_movies_page(movies)
